//---------------------------------------------------------------------
// Arquivo	: tabelahash.hpp
// Conteudo	: definicoes do TAD THASH
// Autor	: Pedro Gomes Santiago Pires Beltrão (pedrosantiago@ufmg.br)
// Historico	: 2021-07-09 - arquivo criado
//		: 2021-07-09 - estrutura de diretorios
//---------------------------------------------------------------------
#include "../include/thash.hpp"

Hash_AB::Hash_AB(int tam_hash)
{//Descricao: construtor
    tamanho = tam_hash;
    Tabela = new CaixaEntrada[tamanho];
};

Email *Hash_AB::Pesquisa(int id_usuario, int id_email)
{//Descricao: pesquisa se o elemento existe chamando o metodo da caixa de entrada
    int pos;
    Email *item = new Email();
    pos = Hash(id_usuario);
    item = Tabela[pos].Pesquisa(id_email, id_usuario);
    return item;
}

int Hash_AB::Insere(Email *mail, int id_usuario)
{//Descricao: insere o elemento chamando o metodo da caixa de entrada
    int pos;
    pos = Hash(id_usuario);
    Tabela[pos].Insere(mail);
    return pos;
}

int Hash_AB::Remove(int id_usuario, int id_email)
{//Descricao: remove o elemento chamando o metodo da caixa de entrada
    int pos;
    pos = Hash(id_usuario);
    return Tabela[pos].Remove(id_email);
}

int Hash_AB::Hash(int id_usuario)
{//Descricao: funcao hash
    return id_usuario % tamanho;
}
