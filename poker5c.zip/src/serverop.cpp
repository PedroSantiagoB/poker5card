//---------------------------------------------------------------------
// Arquivo	: matop.c
// Conteudo	: implementacao do main
// Autor	: Pedro Gomes Santiago Pires Beltrão (pedrosantiago@ufmg.br)
// Historico	: 2021-10-18 - arquivo criado
// Historico	: 2021-07-09 - arquivo criado
//		: 2021-07-09 - estrutura de diretorios
//---------------------------------------------------------------------
#include "thash.hpp"
#include <getopt.h>
#include <cstring>
#include <fstream>
#include <msgassert.hpp>
using namespace std;
char arq_in[100], arq_out[100];
void parse_args(int argc, char **argv)
{//Descricao: recebe os nomes de arquivo de entrada e saida
    // variaveis externas do getopt
    extern char *optarg;
    // variavel auxiliar
    int c;
    // inicializacao variaveis globais para opcoes
    arq_in[0] = 0;
    arq_out[0] = 0;
    // getopt - letra indica a opcao, : junto a letra indica parametro
    // no caso de escolher mais de uma operacao, vale a ultima
    while ((c = getopt(argc, argv, "i:I:m:M:s:S:o:O:h")) != EOF)
    {
        switch (c)
        {
        case 'i':
        case 'I':
            strcpy(arq_in, optarg);
            break;
        case 'o':
        case 'O':
            strcpy(arq_out, optarg);
            break;
        }
    }
}
void processaSaida(char *entrada, char *saida)
{//Descricao: le o arquivo de entrada e processa os dados para o arquivo de saida
    ifstream arq_entrada;
    ofstream arq_saida;
    arq_entrada.open(entrada);
    erroAssert((arq_entrada.is_open()), "Arquivo de entrada não abriu!");// verifica se o arquivo de entrada existe
    arq_saida.open(saida);
    erroAssert((arq_saida.is_open()), "Arquivo de saida não abriu!");// verifica se o arquivo de saida existe
    
    //criando TAD hash de acordo com tamanho lido
    int tam_hash;
    arq_entrada >> tam_hash;
    Hash_AB h(tam_hash);

    //variaveis e tipos utilizadas apenas na leitura e processamento dos dados
    string comando, texto[201];
    int id_usuario, id_email, num_palavras, pos_aux = 0, apaga_aux = 0;
    Email *no_aux = new Email();

    while (arq_entrada >> comando >> id_usuario >> id_email)
    {
        if (comando == "ENTREGA")
        {
            arq_entrada >> num_palavras;
            for (int i = 0; i < num_palavras; i++)
                arq_entrada >> texto[i];
            Email *email = new Email(texto, id_email, num_palavras, id_usuario);
            pos_aux = h.Insere(email, id_usuario);
            arq_saida << "OK: MENSAGEM " << id_email << " PARA " << id_usuario << " ARMAZENADA EM " << pos_aux << endl;
        }
        else if (comando == "CONSULTA")
        {
            no_aux = h.Pesquisa(id_usuario, id_email);
            if (no_aux->id_mail == id_email)//encontrou elemento da pesquisa
            {
                arq_saida << comando << " " << id_usuario << " " << id_email << ": ";
                for (int i = 0; i < no_aux->tam_texto; i++)//laco para impressao do texto
                    if (i == (no_aux->tam_texto - 1))//condicao para ultima palavra
                        arq_saida << no_aux->texto[i] << endl;
                    else
                        arq_saida << no_aux->texto[i] << " ";
            }
            else
                arq_saida << comando << " " << id_usuario << " " << id_email << ": MENSAGEM INEXISTENTE" << endl;
        }
        else if (comando == "APAGA")
        {
            no_aux = h.Pesquisa(id_usuario, id_email);
            if (no_aux->id_mail == id_email)
            {
                apaga_aux = h.Remove(id_usuario, id_email);
                if (apaga_aux)
                    arq_saida << "OK: MENSAGEM APAGADA" << endl;
                else
                    arq_saida << "ERRO: MENSAGEM INEXISTENTE" << endl;
            }
            else
                arq_saida << "ERRO: MENSAGEM INEXISTENTE" << endl;
        }
    }
    arq_saida.close();
    arq_entrada.close();
}
int main(int argc, char **argv)
{
    parse_args(argc, argv);
    processaSaida(arq_in, arq_out);
    return 0;
}