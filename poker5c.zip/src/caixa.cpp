//---------------------------------------------------------------------
// Arquivo	: caixaentrada.hpp
// Conteudo	: implementacao do TAD CAIXA
// Autor	: Pedro Gomes Santiago Pires Beltrão (pedrosantiago@ufmg.br)
// Historico	: 2021-07-09 - arquivo criado
//		: 2021-07-09 - estrutura de diretorios
//---------------------------------------------------------------------
#include "../include/caixa.hpp"
CaixaEntrada::CaixaEntrada()
{//Descricao: inicializacao
    raiz = NULL;
};

CaixaEntrada::~CaixaEntrada()
{//Descricao: limpa toda caixa de entrada
    Limpa();
};

void CaixaEntrada::Insere(Email *mail)
{ 
    InsereRecursivo(raiz, mail);
};

void CaixaEntrada::InsereRecursivo(Email *&p, Email *mail)
{//Descricao: insere um novo elemento na caixa de entrada
    if (p == NULL)
        p = mail; //o no nulo recebe o novo email a ser inserido
    else
    {
        if (mail->id_mail < p->id_mail)
            InsereRecursivo(p->esq, mail);
        else
            InsereRecursivo(p->dir, mail);
    }
};
Email *CaixaEntrada::Pesquisa(int id_email, int id_usuario)
{
    return PesquisaRecursivo(raiz, id_email, id_usuario);
};

Email *CaixaEntrada::PesquisaRecursivo(Email *no, int id_email, int id_usuario)
{//Descricao: pesquisa se um elemento existe na caixa de entrada
    Email *aux = new Email();
    if (no == NULL)
    {
        aux->id_mail = -1; //caso o item nao exista muda o id do email para a comparacao
        return aux;
    }
    if (id_email < no->id_mail)
        return PesquisaRecursivo(no->esq, id_email, id_usuario);
    else if (id_email > no->id_mail)
        return PesquisaRecursivo(no->dir, id_email, id_usuario);
    else
    {
        if (id_usuario == no->id_usuario)
            return no;
        else
            return aux;
    }
};

int CaixaEntrada::Remove(int id_email)
{
    return RemoveRecursivo(raiz, id_email);
};

int CaixaEntrada::RemoveRecursivo(Email *&no, int id_email)
{//Descricao: remove um elemento da da caixa de entrada
    Email *aux;
    if (no == NULL)
        return 0; //representa que o elemento a ser removido nao existe
    if (id_email < no->id_mail)
        return RemoveRecursivo(no->esq, id_email);
    else if (id_email > no->id_mail)
        return RemoveRecursivo(no->dir, id_email);
    else
    {
        if (no->dir == NULL)
        {
            aux = no;
            no = no->esq;
            delete aux;
            return 1;//representa que o elemento a ser removido existe
        }
        else if (no->esq == NULL)
        {
            aux = no;
            no = no->dir;
            delete aux;
            return 1;//representa que o elemento a ser removido existe
        }
        else
        {
            Antecessor(no, no->esq);
            return 1;//representa que o elemento a ser removido existe
        }
    }
};

void CaixaEntrada::Antecessor(Email *q, Email *&r)
{//Descricao: substitui o no pelo antecessor
    if (r->dir != NULL)
    {
        Antecessor(q, r->dir);
        return;
    }
    q->chave = r->chave;
    q = r;
    r = r->esq;
    free(q);
}

void CaixaEntrada::Limpa()
{
    ApagaRecursivo(raiz);
    raiz = NULL;
};

void CaixaEntrada::ApagaRecursivo(Email *p)
{//Descricao: apaga todos elementos da caixa de entrada
    if (p != NULL)
    {
        ApagaRecursivo(p->esq);
        ApagaRecursivo(p->dir);
        delete p;
    }
};