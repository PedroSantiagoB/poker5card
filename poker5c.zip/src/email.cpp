//---------------------------------------------------------------------
// Arquivo	: mensagem.hpp
// Conteudo	: implementacao do TAD EMAIL
// Autor	: Pedro Gomes Santiago Pires Beltrão (pedrosantiago@ufmg.br)
// Historico	: 2021-07-09 - arquivo criado
//		: 2021-07-09 - estrutura de diretorios
//---------------------------------------------------------------------
#include "../include/email.hpp"

Email::Email()
{//Descricao: Inicializacao
    id_usuario = -1;
    tam_texto = -1;
    id_mail = -1;
    *texto = "";
    esq = NULL;
    dir = NULL;
};

Email::Email(std::string *_texto, int _id_mail, int tamanho, int _id_usuario)
{//Descricao: Construtor
    id_usuario = _id_usuario;
    tam_texto = tamanho;
    id_mail = _id_mail;
    for (int i = 0; i < tamanho; i++)
        texto[i] = _texto[i];
}
