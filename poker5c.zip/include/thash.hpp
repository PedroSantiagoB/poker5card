//---------------------------------------------------------------------
// Arquivo	: tabelahash.hpp
// Conteudo	: definicoes do TAD THASH
// Autor	: Pedro Gomes Santiago Pires Beltrão (pedrosantiago@ufmg.br)
// Historico	: 2021-07-09 - arquivo criado
//		: 2021-07-09 - estrutura de diretorios
//---------------------------------------------------------------------
#ifndef THASHHPP
#define THASHHPP

#include "caixa.hpp"
class Hash_AB
{//Descricao: TAD HASH
    public:
        Hash_AB(int tam_hash);
        Email *Pesquisa(int id_usuario, int id_email);
        int Insere(Email *mail, int id_usuario);
        int Remove(int id_usuario, int id_email);
        CaixaEntrada *Tabela;
    private:
        int tamanho;
        int Hash(int id_usuario);
};

#endif