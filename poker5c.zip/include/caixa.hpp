//---------------------------------------------------------------------
// Arquivo	: caixaentrada.hpp
// Conteudo	: implementacao do TAD CAIXA
// Autor	: Pedro Gomes Santiago Pires Beltrão (pedrosantiago@ufmg.br)
// Historico	: 2021-07-09 - arquivo criado
//		: 2021-07-09 - estrutura de diretorios
//---------------------------------------------------------------------
#ifndef CAIXAHPP
#define CAIXAHPP
#include "email.hpp"
class CaixaEntrada
{//Descricao: TAD CaixaEntrada
    public:
        CaixaEntrada();
        ~CaixaEntrada();
        void Insere(Email *mail);
        void Caminha();
        Email *Pesquisa(int id_email, int id_usuario);
        int Remove(int id_email);
        void Limpa();
    private:
        void InsereRecursivo(Email *&p, Email *mail);
        void ApagaRecursivo(Email *p);
        Email *PesquisaRecursivo(Email *p, int id_email, int id_usuario);
        int RemoveRecursivo(Email *&p, int id_email);
        void Antecessor(Email *q, Email *&r);
        Email *raiz;
};
#endif