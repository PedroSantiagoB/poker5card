//---------------------------------------------------------------------
// Arquivo	: mensagem.hpp
// Conteudo	: implementacao do TAD EMAIL
// Autor	: Pedro Gomes Santiago Pires Beltrão (pedrosantiago@ufmg.br)
// Historico	: 2021-07-09 - arquivo criado
//		: 2021-07-09 - estrutura de diretorios
//---------------------------------------------------------------------
#ifndef EMAILHPP
#define EMAILHPP
#include <iostream>
class Email
{//Descricao: TAD EMAIL
    public:
        Email();
        Email(std::string _texto[201], int _id_mail, int tamanho, int _id_usuario);
        int tam_texto;
        int id_mail;
        int id_usuario;
        std::string texto[201];
    private:
        int chave;
        Email *esq;
        Email *dir;
        friend class CaixaEntrada;
        friend class Hash_AB;
};
#endif